"""Double-click this file to start the ivserial window (Python 3 with numpy and scipy required)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from ivserial.gui import main
except ImportError as e:  # missing numpy/scipy
    import tkinter as tk
    from tkinter import messagebox
    tk.Tk().withdraw()
    messagebox.showerror("ivserial", f"A required package is missing: {e}\n\nOpen a terminal and run:\n"
                         "python -m pip install numpy scipy")
    raise SystemExit(1)
main()
