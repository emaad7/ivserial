@echo off
cd /d "%~dp0"
python ivserial_gui.pyw
if errorlevel 1 py ivserial_gui.pyw
